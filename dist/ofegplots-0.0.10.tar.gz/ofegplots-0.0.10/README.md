# ofegplots for OpenFOAM postprocessing

![](https://github.com/uqyge/ofegplots/workflows/Pypi%20ofegplots/badge.svg)
