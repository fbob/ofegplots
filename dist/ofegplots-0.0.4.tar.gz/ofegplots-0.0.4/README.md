# ofegplots for OpenFOAM postprocessing

![](https://github.com/uqyge/ofegplots/workflows/.github/workflows/main.yml/badge.svg)
